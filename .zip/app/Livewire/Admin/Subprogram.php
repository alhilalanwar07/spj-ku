<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class Subprogram extends Component
{
    public function render()
    {
        return view('livewire.admin.subprogram');
    }
}
