import './bootstrap';
import AutoNumeric from 'autonumeric';
